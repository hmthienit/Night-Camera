package itac.minhthienstyle.nightcamera.Process;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import itac.minhthienstyle.nightcamera.R;

public class ProcessImages extends AppCompatActivity {

    final int REQUEST_EXTERNAL_STORAGE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_process_images);
//        getSupportActionBar().setTitle("Xử Lý Ảnh");


        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("filename", PackageManager.PERMISSION_GRANTED + " PacketManager");
                Log.d("filename", ActivityCompat.checkSelfPermission(ProcessImages.this, Manifest.permission.READ_EXTERNAL_STORAGE) + " Manifest");
                if (ActivityCompat.checkSelfPermission(ProcessImages.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(ProcessImages.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_EXTERNAL_STORAGE);
//                    return;
                } else {
                    launchGalleryIntent();
                }
            }
        });
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    public void launchGalleryIntent() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.setType("image/*");
        startActivityForResult(intent, REQUEST_EXTERNAL_STORAGE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_EXTERNAL_STORAGE: {
                // If request is cancelled, the result arrays are empty.
                Log.d("filename", grantResults.length + "Grant");
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d("filename", "accepted the permission!");
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                    launchGalleryIntent();
                } else {
                    Log.d("filename", "permission denied");
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request.
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_EXTERNAL_STORAGE && resultCode == RESULT_OK) {

            final ImageView imageView = findViewById(R.id.image_view);
            final List<Bitmap> bitmaps = new ArrayList<>();
            ClipData clipData = data.getClipData();

            if (clipData != null) {
                //multiple images selecetd
                for (int i = 0; i < clipData.getItemCount(); i++) {
                    Uri imageUri = clipData.getItemAt(i).getUri();
                    Log.d("URI", imageUri.toString());
                    try {
                        InputStream inputStream = getContentResolver().openInputStream(imageUri);
                        Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                        bitmaps.add(bitmap);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            } else {
                //single image selected
                Uri imageUri = data.getData();
//                Log.d("URI", imageUri.toString());
                try {

                    InputStream inputStream = getContentResolver().openInputStream(imageUri);
                    BitmapFactory.Options options = new BitmapFactory.Options();
                    options.inJustDecodeBounds = true;

                    Bitmap bitmap = BitmapFactory.decodeStream(inputStream, null, options);
                    Log.d("filename", options.outWidth + "is Width" + options.outHeight + "is Height");
                    bitmaps.add(bitmap);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

            }

//            new Thread(new Runnable() {
//                @Override
//                public void run() {
//                    for (final Bitmap b : bitmaps) {
//                        runOnUiThread(new Runnable() {
//                            @Override
//                            public void run() {
//                                imageView.setImageBitmap(mergeMultiple((ArrayList<Bitmap>) bitmaps));
//                            }
//                        });
//
//                        try {
//                            Thread.sleep(3000);
//                        } catch (InterruptedException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                }
//            }).start();

            imageView.setImageBitmap(mergeBitmap((ArrayList<Bitmap>) bitmaps));
//            imageView.setImageBitmap(mergeMultiple((ArrayList<Bitmap>) bitmaps));
            saveImageFile(mergeBitmap((ArrayList<Bitmap>) bitmaps));
            Toast.makeText(this, "Lưu ảnh thành công!", Toast.LENGTH_SHORT).show();
//            mergeMultiple((ArrayList<Bitmap>) bitmaps);
        }
    }

    public String saveImageFile(Bitmap bitmap) {
        FileOutputStream out = null;
        String filename = getFilename();
        try {
            out = new FileOutputStream(filename);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        Log.d("filename", filename + "fffffffffffffffffffff");
        return filename;
    }

    private String getFilename() {
        File file = new File(Environment.getExternalStorageDirectory()
                .getPath(), "DCIM/NightCamera");
        if (!file.exists()) {
            file.mkdirs();
        }
        String uriSting = (file.getAbsolutePath() + "/"
                + System.currentTimeMillis() + ".jpg");
        Log.d("Alpha", "Alpha: " + uriSting);
        return uriSting;
    }

    private Bitmap mergeBitmap(ArrayList<Bitmap> b){
        Bitmap newBitmap = Bitmap.createBitmap(b.get(0).getWidth(), b.get(0).getHeight(), Bitmap.Config.ARGB_8888);
//        Log.d("Alpha", "width: " + b.get(0).getWidth());
//        Log.d("Alpha", "height: " + b.get(0).getHeight());
        Canvas canvas = new Canvas(newBitmap);
        Paint alphaPaint = new Paint();
        float opacity = 100;
        for (int i = 0; i< b.size(); i++){
            alphaPaint.setAlpha((int)(255/(100/opacity)));
//            if (b.get(i) == b.get(1) || b.get(i) == b.get(2)){
////                alphaPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
//                canvas.drawBitmap(b.get(i),0,0, alphaPaint);
////                canvas.drawBitmap(new MedianFilter(b.get(i), 4).applyFilter(), 0, 0, alphaPaint);
//            }else{
//            b.get(0).setPixel( 100,  100, Color.GREEN);
//            canvas.drawBitmap(new MedianFilter(b.get(i), 3).applyFilter(), 0, 0, alphaPaint);
                canvas.drawBitmap(b.get(i), 0, 0, alphaPaint);
                opacity/=2;
//            }
        }

        return newBitmap;
//        return new MedianFilter(newBitmap, 3).applyFilter();
    }


    private Bitmap mergeMultiple(ArrayList<Bitmap> parts) {

        Bitmap result = Bitmap.createBitmap(parts.get(0).getWidth(), parts.get(0).getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        Paint paint = new Paint();
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
        for (int i = 0; i < parts.size(); i++) {
            canvas.drawBitmap(parts.get(i), 0, 0, paint);
        }
        return result;
    }
}

